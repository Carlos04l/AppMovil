package com.example.dragoncity

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {

    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Acerca del Juego") }
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.Start
        ) {

            Text(
                text = "¿Qué es Dragon City?",
                style = MaterialTheme.typography.titleLarge
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Dragon City es un juego de simulación y estrategia desarrollado por Social Point. Fue lanzado en 2012 y está disponible en Android, iOS y Facebook."
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Objetivo del juego",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "El objetivo principal es coleccionar, entrenar y cruzar dragones para expandir tu ciudad, ganar oro y competir en batallas."
            )

            Spacer(modifier = Modifier.height(24.dp))

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Tipos de Dragones",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text("• Comunes: fáciles de obtener y básicos para iniciar.")
            Spacer(modifier = Modifier.height(4.dp))

            Text("• Raros: requieren combinaciones específicas para criarlos.")
            Spacer(modifier = Modifier.height(4.dp))

            Text("• Legendarios: difíciles de conseguir y más poderosos.")
            Spacer(modifier = Modifier.height(4.dp))

            Text("• Heroicos: los más exclusivos y fuertes del juego.")

            Button(
                onClick = onBack,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Volver")
            }
        }
    }
}