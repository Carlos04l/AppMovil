package com.example.dragoncity

data class Dragon(
    val name: String,
    val element: String,
    val habitat: String,
    val evolution: String,
    val strongAgainst: String,
    val weakAgainst: String,
    val description: String,
    val image: Int
)
