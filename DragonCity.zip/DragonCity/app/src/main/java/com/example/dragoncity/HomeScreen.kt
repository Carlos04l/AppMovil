package com.example.dragoncity

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.clickable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape




@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onLogout: () -> Unit,
    onGoToAbout: () -> Unit
) {

    val auth = FirebaseAuth.getInstance()
    val userEmail = auth.currentUser?.email ?: "Usuario"

    val dragons = listOf(

        Dragon(
            "Dragon Tierra",
            "Tierra",
            "Tierra",
            "Nivel 4 y 7",
            "Eléctrico",
            "Metal",
            "No tengas miedo! No es un terremoto, solo el majestuoso dragón terra que ha salido pasear. Estas criaturas son famosas por su amor por la suciedad y tienen una naturaleza humilde y honesta.",
            R.drawable.terra_dragon
        ),

        Dragon(
            "Dragon Fuego",
            "Fuego",
            "Fuego",
            "Nivel 4 y 7",
            "Natura",
            "Agua",
            "Si no soportas el calor, ¡ni te acerques a él! Esta criatura temperamental saca su genio enseguida, pero se calma rápido y siempre siente un remordimiento profundo por todo lo que quema.",
            R.drawable.flame_dragon
        ),

        Dragon(
            "Dragon mar",
            "Agua",
            "Mar",
            "Nivel 4 y 7",
            "Fuego",
            "Eléctrico",
            "Si te van los deportes acuáticos, entonces el dragón mar y tú seréis inseparables. A menudo se los confunde con focas o delfines",
            R.drawable.sea_dragon
        ),

        Dragon(
            "Dragon Natura",
            "Natura",
            "Natura",
            "Nivel 4 y 7",
            "Agua",
            "Fuego",
            "Al dragón natura le encantan los humanos, los animales y todos los seres vivos; algunos para fines gastronómicos. No parece que se haya comido a ningún humano entero, pero algún dedo seguro que si...",
            R.drawable.nature_dragon
        ),

        Dragon(
            "Dragon Electrico",
            "Eléctrico",
            "Electrico",
            "Nivel 4 y 7",
            "Agua",
            "Tierra",
            "Según cuenta la leyenda, nació dentro de una gran tormenta que tuvo lugar en los años oscuros, cuando un dragón normal fue alcanzado por un rayo. Desde entonces, pueden verse en el cielo, buscando una descarga.",
            R.drawable.electric_dragon
        ),

        Dragon(
            "Dragon Hielo",
            "Hielo",
            "Hielo",
            "Nivel 4 y 7",
            "Natura",
            "Fuego",
            "Con tanto cambio climático, los dragones hielo han emigrado al Polo Norte. Si ves alguno en un sitio cálido, envíalo directamente a la primera pista de hielo que veas y te lo agradecerá de por vida",
            R.drawable.ice_dragon
        ),

        Dragon(
            "Dragon Metal",
            "Metal",
            "Metal",
            "Nivel 4 y 7",
            "Tierra",
            "Eléctrico",
            "Un dragón robusto al que le atrae todo lo que es de metal. Se rumorea que lo que le falta de inteligencia lo compensa con determinación.",
            R.drawable.metal_dragon
        ),

        Dragon(
            "Dragon Oscuro",
            "Tinieblas",
            "Tinieblas",
            "Nivel 4 y 7",
            "Luz",
            "Luz",
            "Una criatura muy difícil de localizar, apenas unos cuantos afortunados han logrado verla de noche. Entre su color y que es noctámbula, ¡es imposible verla!",
            R.drawable.dark_dragon
        ),

        Dragon(
            "Dragon Arcángel",
            "Luz",
            "Luz",
            "Nivel 4 y 7",
            "Tinieblas",
            "Tinieblas",
            "Deus creó al dragón arcángel cuando era joven y valiente. Siempre elige a esta criatura para llevar a cabo sus tareas.",
            R.drawable.light_dragon
        ),

        Dragon(
            "Dragon Bélico",
            "Bélico",
            "Bélico",
            "Nivel 4 y 7",
            "Tierra",
            "Luz",
            "Todos los imperios han temido alguna vez al imponente dragón bélico. Destruye todo lo que encuentra a su paso: edificios, puentes, dragones... ;hasta la moral del adversario!",
            R.drawable.war_dragon
        ),

        Dragon(
            "Dragon Puro",
            "Puro",
            "Puro",
            "Nivel 4 y 7",
            "Legendario",
            "Bélico",
            "Dragón muy poderoso con energía pura.",
            R.drawable.pure_dragon
        ),

        Dragon(
            "Dragon Legado",
            "Legendario",
            "Leyenda",
            "Nivel 4 y 7",
            "Todos",
            "Puro",
            "¿Te imaginas una criatura que, de tan pura, emanase una luz cegadora? ¡No se puede describir con palabras al dragón puro, así que mejor lo experimentas en persona!",
            R.drawable.legendary_dragon
        ),

        Dragon(
            "Dragon Primario",
            "Primario",
            "Primario",
            "Nivel 4 y 7",
            "Legendario",
            "Luz",
            "Si el dragón primario te parece un poco nervioso, dale tiempo. Ha estado buscando Dragon City mucho tiempo, pero se ha distraído en cada uno de los portales. Al ser uno de los dragones más juguetones del elemento primario, lo que más le gusta es que le presten atención.",
            R.drawable.primal_dragon
        )
    )




    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Dragon City") }
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        )
        {

            Text(
                text = "Bienvenido",
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Sesión iniciada como:",
                style = MaterialTheme.typography.bodyMedium
            )

            Text(
                text = userEmail,
                style = MaterialTheme.typography.bodyLarge
            )

            Spacer(modifier = Modifier.height(24.dp))

            InfoCard(
                title = "🏝 Hábitats",
                description = "Los dragones viven en diferentes tipos de hábitats según su elemento."
            )

            Spacer(modifier = Modifier.height(16.dp))

            InfoCard(
                title = "📈 Niveles",
                description = "Puedes subir de nivel ganando experiencia al alimentar y entrenar dragones."
            )

            Spacer(modifier = Modifier.height(16.dp))

            InfoCard(
                title = "🎉 Eventos",
                description = "Dragon City ofrece eventos especiales con recompensas exclusivas."
            )

            Text(
                text = "Enciclopedia de Dragones",
                style = MaterialTheme.typography.titleLarge
            )

            Spacer(modifier = Modifier.height(12.dp))

            dragons.forEach { dragon ->
                DragonCard(dragon)
            }

            Spacer(modifier = Modifier.height(24.dp))


            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { onGoToAbout() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text("Acerca del juego")
            }


            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = { showDialog = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Cerrar sesión")
            }

            if (showDialog) {
                AlertDialog(
                    onDismissRequest = { showDialog = false },
                    title = { Text("Cerrar sesión") },
                    text = { Text("¿Estás seguro que deseas cerrar sesión?") },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                auth.signOut()
                                showDialog = false
                                onLogout()
                            }
                        ) {
                            Text("Sí")
                        }
                    },
                    dismissButton = {
                        TextButton(
                            onClick = { showDialog = false }
                        ) {
                            Text("Cancelar")
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun InfoCard(title: String, description: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium
            )


        }
    }
}

@Composable
fun DragonCard(dragon: Dragon) {

    var expanded by remember { mutableStateOf(false) }

    val cardColor = when (dragon.element) {
        "Tierra" -> Color(0xFFD7CCC8)
        "Fuego" -> Color(0xFFFFCDD2)
        "Agua" -> Color(0xFFBBDEFB)
        "Natura" -> Color(0xFFC8E6C9)
        "Eléctrico" -> Color(0xFFFFF59D)
        "Hielo" -> Color(0xFFE1F5FE)
        "Metal" -> Color(0xFFE0E0E0)
        "Tinieblas" -> Color(0xFFD1C4E9)
        "Luz" -> Color(0xFFFFF9C4)
        "Bélico" -> Color(0xFFFFA726)
        "Puro" -> Color(0xFF0748BB)
        "Legendario" -> Color(0xFF8E24AA)
        "Primario" -> Color(0xFFFF1744)
        else -> MaterialTheme.colorScheme.surface
    }


    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { expanded = !expanded },

        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),

        shape = RoundedCornerShape(16.dp),

        colors = CardDefaults.cardColors(
            containerColor = cardColor
        )

    ) {


    Column(modifier = Modifier.padding(16.dp)) {

            Image(
                painter = painterResource(id = dragon.image),
                contentDescription = dragon.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = dragon.name,
                style = MaterialTheme.typography.titleLarge
            )

            AnimatedVisibility(visible = expanded) {

                Column {

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Elemento: ${dragon.element}")
                    Text("Hábitat: ${dragon.habitat}")
                    Text("Evolución: ${dragon.evolution}")
                    Text("Fuerte contra: ${dragon.strongAgainst}")
                    Text("Débil contra: ${dragon.weakAgainst}")

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(dragon.description)
                }

            }

        }
    }
}
