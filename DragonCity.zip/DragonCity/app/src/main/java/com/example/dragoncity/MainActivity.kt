package com.example.dragoncity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.dragoncity.ui.theme.DragonCityTheme
import androidx.compose.runtime.setValue
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            val auth = FirebaseAuth.getInstance()

            var currentScreen by remember {
                mutableStateOf(
                    if (auth.currentUser != null) "home" else "login"
                )
            }

            when (currentScreen) {

                "login" -> LoginScreen(
                    onLoginSuccess = {
                        currentScreen = "home"
                    },
                    onGoToRegister = {
                        currentScreen = "register"
                    }
                )

                "register" -> RegisterScreen(
                    onRegisterSuccess = {
                        currentScreen = "login"
                    },
                    onGoToTerms = {
                        currentScreen = "terms"
                    },
                    onGoToLogin = {
                        currentScreen = "login"
                    }
                )

                "home" -> HomeScreen(
                    onLogout = {
                        currentScreen = "login"
                    },
                    onGoToAbout = {
                        currentScreen = "about"
                    }
                )

                "terms" -> TermsScreen(
                    onAccept = {
                        currentScreen = "register"
                    },
                    onBack = {
                        currentScreen = "register"
                    }
                )

                "about" -> AboutScreen(
                    onBack = {
                        currentScreen = "home"
                    }
                )
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    DragonCityTheme {
        Greeting("Android")
    }
}