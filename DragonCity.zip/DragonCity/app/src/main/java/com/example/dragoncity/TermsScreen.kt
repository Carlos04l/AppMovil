package com.example.dragoncity

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun TermsScreen(onAccept: () -> Unit, onBack: () -> Unit) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            text = "Términos y Condiciones",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {

            Text(
                text = """
1. Uso de la aplicación
Esta aplicación informativa sobre Dragon City es un proyecto académico desarrollado con fines educativos.

2. Registro de usuario
El usuario debe proporcionar un correo válido y una contraseña segura para acceder a la aplicación.

3. Protección de datos
Los datos registrados se almacenan mediante Firebase Authentication y no se comparten con terceros.

4. Contenido informativo
La información mostrada sobre hábitats, niveles y eventos es únicamente con fines académicos.

5. Responsabilidad
El desarrollador no se hace responsable por el uso indebido de la aplicación.

6. Aceptación
Al registrarse, el usuario acepta estos términos y condiciones.
                """.trimIndent()
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { onAccept() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Aceptar")
        }

        Spacer(modifier = Modifier.height(8.dp))

        TextButton(
            onClick = { onBack() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Volver")
        }
    }
}